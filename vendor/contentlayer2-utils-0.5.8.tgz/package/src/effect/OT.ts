import * as T from '@effect-ts/core/Effect'
import type * as S from '@effect-ts/core/Effect/Experimental/Stream'

// Contentlayer's generated content does not require a tracing environment.
// Preserve the Effect and Stream values while dropping the obsolete OTel 1 SDK.
export type HasTracer = unknown
export type HasSpan = unknown

export const withSpan = (_name: string, _options?: unknown) =>
  <R, E, A>(effect: T.Effect<R, E, A>): T.Effect<R, E, A> => effect

export const addAttribute = (_name: string, _value: unknown) => T.succeed(undefined)
export const addEvent = (_name: string, _attributes?: unknown) => T.succeed(undefined)

export const withStreamSpan = (_name: string, _options?: unknown, _context?: unknown) =>
  <R, E, A>(stream: S.Stream<R, E, A>): S.Stream<R, E, A> => stream

import type * as T from '@effect-ts/core/Effect'

// The Blog does not export Contentlayer build traces. Keep the provider API so
// Contentlayer's Effect composition and document generation stay unchanged.
export const DummyTracing = {}

export const provideDummyTracing = <R, E, A>(effect: T.Effect<R, E, A>): T.Effect<R, E, A> => effect

export const provideTracing = (_serviceName: string, _tracer: 'dummy' | 'otel' | 'based-on-env' = 'based-on-env') =>
  provideDummyTracing

export const provideJaegerTracing = (_serviceName: string) => provideDummyTracing
